# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from openerp.exceptions import ValidationError
from openerp import api, exceptions, fields, models, _
import requests
import json
from base64 import encode

class Respartner(models.Model):
    _inherit = 'res.partner'

    customer_id=fields.Char('Customer ID')
    nick_name=fields.Char('NickName')
    first_name=fields.Char('FirstName')
    last_name=fields.Char('LastName')
    fax_no=fields.Char('FaxNo')
    contact_id=fields.Char('ContactId')
    is_express=fields.Boolean('IsExpress')
    apartment_suite=fields.Char('ApartmentSuite')
    province_region=fields.Char('ProvinceRegion')
    is_user_defalut=fields.Boolean('IsUserDefault')
    total_contact=fields.Char('TotalContacts')
    contact_type=fields.Integer('ContactType')
    ups_pick_uptype=fields.Integer('UPSPickUpType')
    is_residential=fields.Boolean('IsResidential')

    @api.model
    def create(self, vals):
        vals['customer_id'] = self.env['ir.sequence'].next_by_code('res.partner') or _('New')
        result = super(Respartner, self).create(vals)
        return result

    @api.onchange('first_name','last_name')
    def _onchange_name(self):
    	name=self.first_name
    	if self.last_name:
    		name=name +'  '+str(self.last_name)
    	self.name=name
