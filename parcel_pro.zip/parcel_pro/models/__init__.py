# -*- coding: utf-8 -*-

from . import parcel_configuration
from . import res_users
from . import res_partner
from . import sale_order
from . import stock_picking